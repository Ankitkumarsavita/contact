<?php
include 'conn.php';
session_start();
$user_id = $_SESSION['userid'];
// echo"<pre>"; 
// print_r($user_id);
// exit();

$page_number = "";
if (isset($_GET["page_no"])) {
    
    $page_number = $_GET["page_no"];
} else {
    $page_number = 1;
}
$records_per_page = 5;
$records_per_page = isset($_GET["records_per_page"]) ? $_GET["records_per_page"] : 5;
$offset = ($page_number - 1) * $records_per_page;

$select_query = "SELECT * FROM contact WHERE userid = '$user_id' ORDER BY id DESC LIMIT $offset, $records_per_page";

$result_set = mysqli_query($conn, $select_query);

// Check for errors in the query
if (!$result_set) {
    $error_message = "Error: " . mysqli_error($conn);
    echo json_encode(['success' => false, 'message' => $error_message]);
    exit;
}
// Fetch data and display in the table
$return_arr = array();
if (mysqli_num_rows($result_set) > 0) {
    
    while ($row = mysqli_fetch_array($result_set)) {
        $id = $row['id'];
        $name = $row['name'];
        $email = $row['email'];
        $number = $row['number'];
        
        $return_arr[] = array(
            "id" => $id,
            "name" => $name,
            "email" => $email,
            "number" => $number
        );
    }
}

$output = ''; 
$sql_total = "SELECT* FROM contact";
$records = mysqli_query($conn, $sql_total) or die("query unsuccessfull");
$total_record = mysqli_num_rows($records);
$total_pages = ceil($total_record / $records_per_page);
for ($i = 1; $i <= $total_pages; $i++) {
    $output .= "<a class= 'active' id = '{$i}' href=''> {$i}";
}
for ($i = 1; $i <= $total_pages; $i++) {
    $output .= "<a class='active' id='$i' href='?page_no=$i&records_per_page=$records_per_page'>$i</a>";
}

echo json_encode($return_arr);


// echo json_encode( ['success' => true, 'data' => $return_arr, 'message' => 'Data fetched successfully']);
?>