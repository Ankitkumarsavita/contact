// groupData();
// function groupData() {
//   $.ajax({
//     url: "./display_group.php",
//     type: "GET",
//     dataType: "JSON",
//     data: { name:group_name},
//     success: function (response) {
//       console.log("response");
//       console.log(response);
//       var len = response.length;
//       $("#grouptable").empty();
//       for (var i = 0; i < len; i++) {
//         var group_name= response[i].group_name;
//         var tr_str =
//           "<tr>" +
//           "<td>" +
//           group_name +
//           "</td>"+
//           "<td>" +
//           "<button class='btn btn-success edit-id ' data-id='" +
//           id +
//           "'>Edit</button>" +
//           " <button class='btn btn-success delete-id' data-id='" +
//           id +
//           "'>Delete</button>" +
//           "</td>" +
//           "</tr>"; 
//           $("#grouptable").append(tr_str);
//       }
     
//     },
//   });
// }
$(document).ready(function () {
    $("#group-submit").click(function () {
        // Get the form data
        var formData = $("#groupForm").serialize();
        
        // Make an AJAX request to handle form submission
        $.ajax({
            type: "POST",
            url: "./grouppage.php", // Replace with the actual PHP script handling the form data
            data: formData,
            success: function (response) {
                // Handle the response if needed
                console.log(response);
                // Optionally, close the modal or perform other actions
                $("#groupexampleModal").modal("hide");
            }
        });
    });
});
