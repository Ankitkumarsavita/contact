$(document).ready(function () {
    $("#signupbtn").on("click", function () {
      // event.preventDefault();
      var formData = new FormData($('#signupForm')[0]); 
      $.ajax({
        url: "./signup_reg.php",
        type: "POST",
        data: formData,
        processData: false, 
        contentType: false, 
        dataType: "JSON",
        success: function (res) {
            // res = JSON.parse(result);
           console.log(res);

           if (res.success) {
            $("#signupMessage").text("Signup successful!").show();
            setTimeout(function () {
              $("#signupMessage").hide();
              console.log("Redirecting...");
              window.location.href = "./index.php";
            }, 1000);
          }else {
            
            console.log("tttt");
            $("#sign_name_msg").empty();
            $("#sign_email_msg").empty();
            $("#sign_password_msg").empty();
            $("#confirm_password_msg").empty();
  
            $.each(res.messages, function (index, message) {
              // console.log("tttt");
              if (message.field === "name") {
                $("#sign_name_msg").text(message.error);
              } else if (message.field === "email") {
                $("#sign_email_msg").text(message.error);
              } else if (message.field === "password") {
                $("#sign_password_msg").text(message.error);
              } else if (message.field === "confirm_password") {
                $("#confirm_password_msg").text(message.error);
              }
            });
          }
          $('#signupForm')[0].reset();
        },
        error: function (error) {
          console.log(error);
        },
      });
    });
  });