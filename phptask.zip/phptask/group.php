<?php
include 'conn.php';
session_start();
if (isset($_POST['op'])) {
    $name = $_POST['name'];
    $sql = 'INSERT INTO `group` (name) VALUES ("' . $name . '")';
    $result = mysqli_query($conn, $sql);

    if ($result) {
        echo json_encode(['success' => true, 'message' => 'Record updated']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error updating record: ' . mysqli_error($conn)]);
    }
}

