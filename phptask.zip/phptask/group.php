<?php
// include 'conn.php';
// // session_start()
// if (isset($_POST['op'])) {
//     $name = $_POST['name'];
//     $sql = 'INSERT INTO `group` (name) VALUES ("' . $name . '")';
//     $result = mysqli_query($conn, $sql);

//     if ($result) {
//         $lastInsertId = mysqli_insert_id($conn);
//         $selectQuery = 'SELECT * FROM `group`';
//         $selectResult = mysqli_query($conn, $selectQuery);
        
//         if ($selectResult) {
//             $groups = [];
//             while ($row = mysqli_fetch_assoc($selectResult)) {
//                 $groups[] = $row;
//             }

//             echo json_encode(['success' => true, 'message' => 'Record updated', 'groups' => $groups]);
//         } else {
//             echo json_encode(['success' => false, 'message' => 'Error fetching groups: ' . mysqli_error($conn)]);
//         }
//     } else {
//         echo json_encode(['success' => false, 'message' => 'Error updating record: ' . mysqli_error($conn)]);
//     }
// }
?> 
