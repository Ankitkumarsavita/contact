<?php
include 'conn.php';
session_start();
$user_id = $_SESSION['userid'];
/*pagination */
$page_number = isset($_GET["page_no"]) ? $_GET["page_no"] : 1;
$records_per_page = isset($_GET["records_per_page"]) ? $_GET["records_per_page"] : 5;
$offset = ($page_number - 1) * $records_per_page;
/*search dropdown */
$search_term = isset($_GET["search_term"]) ? $_GET["search_term"] : "";
$search_condition = $search_term != "" ? "AND name LIKE '$search_term%'" : "";
$select_query = "SELECT * FROM contact WHERE userid = '$user_id' $search_condition ORDER BY id DESC LIMIT $offset, $records_per_page";
$result_set = mysqli_query($conn, $select_query);
if (!$result_set) {
    $error_message = "Error: " . mysqli_error($conn);
    echo json_encode(['success' => false, 'message' => $error_message]);
    exit;
}


$return_arr = array();
if (mysqli_num_rows($result_set) > 0) {
    while ($row = mysqli_fetch_array($result_set)) {
        $id = $row['id'];
        $name = $row['name'];
        $email = $row['email'];
        $number = $row['number'];
        $group_id = $row['group_id'];
        
        $group_name_query = "SELECT name FROM `group` WHERE id = $group_id";
        
        $group_name_result = mysqli_query($conn, $group_name_query);
        
            $group_name_row = mysqli_fetch_assoc($group_name_result);
            $group_name = $group_name_row['name'];
        
        $return_arr[] = array(
            "id" => $id,
            "name" => $name,
            "email" => $email,
            "number" => $number,
            "group_name" => $group_name 
        );
    }
}

$output = '';
$sql_total = "SELECT COUNT(*) AS total_records FROM contact WHERE userid = '$user_id' $search_condition";
$total_records_result = mysqli_query($conn, $sql_total);
$total_records_row = mysqli_fetch_assoc($total_records_result);
$total_record = $total_records_row['total_records'];

$total_pages = ceil($total_record / $records_per_page);

for ($i = 1; $i <= $total_pages; $i++) {
    $output .= "<a class='active' id='$i' href='?page_no=$i&records_per_page=$records_per_page'>$i</a>";
}


echo json_encode($return_arr);


// echo json_encode( ['success' => true, 'data' => $return_arr, 'message' => 'Data fetched successfully']);
