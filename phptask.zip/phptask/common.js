/*use for Edit button This part listens for a click event on elements with the class edit-id */
$(document).ready(function () {
  $(document).on("click", ".edit-id", function () {
    var id = $(this).data("id");

    $.ajax({
      url: "./edit.php",
      type: "GET",
      data: { id: id },
      dataType: "json",
      success: function (response) {
        fetchData(id);
      },
      error: function (xhr, status, error) {
        console.error(xhr.responseText);
      },
    });
  });
  /*use for edit Updates the form fields with the fetched data and shows the modal */
  function fetchData(id) {
    $.ajax({
      url: "./edit.php",
      type: "GET",
      data: { id: id },
      dataType: "json",
      success: function (response) {
        console.log(response);
        if (response.success) {
          console.log(response.data.id);
          $("#update-id").val(id);
          $("#update-name").val(response.data.name);
          $("#update-email").val(response.data.email);
          $("#update-number").val(response.data.number);

          // Show the modal
          // // $("#update_email_msg").text("");
          // $("#update_email_msg").text("");
          $("#edit_name_msg").text("");
          $("#edit_email_msg").text("");
          $("#edit_number_msg").text("");

          $("#exampleModal1").modal("show");
        } else {
          // Handle errors if needed
          alert("Error");
        }
      },
      error: function (xhr, status, error) {
        console.error(xhr.responseText);
      },
    });
  }
});
/*edit update and showing error popup The success callback handles the response from the server. If the update is successful (res.success is true), it hides the modal. If there is an error, it displays the error message in the #update_email_msg element. */

$("#update_submit").on("click", function () {
  $.ajax({
    url: "./edit.php",
    type: "POST",
    data: {
      id: $("#update-id").val(),
      name: $("#update-name").val(),
      email: $("#update-email").val(),
      number: $("#update-number").val(),
      op: "update",
    },

    success: function (response) {
      res = JSON.parse(response);
      console.log(res.success);
      if (res.success) {
        getData();
        $("#exampleModal1").modal("hide");
      } else {
        // $("#update_email_msg").text(res.message);
        $("#edit_name_msg").empty();
        $("#edit_email_msg").empty();
        $("#edit_number_msg").empty();

        $.each(res.messages, function (index, message) {
          if (message.field === "name") {
            $("#edit_name_msg").text(message.error);
          } else if (message.field === "email") {
            $("#edit_email_msg").text(message.error);
          } else if (message.field === "number") {
            $("#edit_number_msg").text(message.error);
          }
        });
      }
    },
    error: function (xhr, status, error) {
      console.error(xhr.responseText);
    },
  });
});
/*add popup The success callback handles the response from the server. If the insertion is successful (res.success is true), it hides the modal. If there is an error, it displays error messages in the respective elements (#add_name_msg, #add_email_msg, #add_number_msg).*/

$("#add_submit").on("click", function () {
  $.ajax({
    url: "./insert.php",
    type: "POST",
    data: {
      name: $("#recipient-name").val(),
      email: $("#recipient-email").val(),
      number: $("#recipient-number").val(),
      op: "insert",
    },
    success: function (result) {
      res = JSON.parse(result);
      console.log(res);
      if (res.success) {
        $("#exampleModal").modal("hide");
        getData();
      } else {
        $("#add_name_msg").empty();
        $("#add_email_msg").empty();
        $("#add_number_msg").empty();

        $.each(res.messages, function (index, message) {
          if (message.field === "name") {
            $("#add_name_msg").text(message.error);
          } else if (message.field === "email") {
            $("#add_email_msg").text(message.error);
          } else if (message.field === "number") {
            $("#add_number_msg").text(message.error);
          }
        });
      }
    },
  });
});

/*delete confirmation popup */
$(document).ready(function () {
  $(document).on("click", ".delete-id", function () {
    var id = $(this).data("id");
    window.currentDeleteId = id;
    $("#exampleModal2").modal("show");
  });

  $(document).on("click", "#delete_submit", function () {
    var id = window.currentDeleteId;
    $.ajax({
      url: "./delete.php",
      type: "POST",
      data: {
        id: id,
        delete_submit: true,
      },
      // dataType: 'json',
      success: function (response) {
        var response = JSON.parse(response);
        console.log(response);
        if (response.success) {
          $("#exampleModal2").modal("hide");
          getData();
          // showMessage("Item successfully deleted!");
        }
        // else{
        //   showMessage("Error deleting item. Please try again.");
        // }
      },
    });
  });
  // function showMessage(message) {
  //   // You can replace this with your own logic to display the message
  //   // For example, using a popup/modal or an alert
  //   alert(message);
  // }
});

/*without page roloding*/

getData();
function getData() {
  $.ajax({
    url: "./display.php",
    type: "GET",
    dataType: "JSON",
    success: function (response) {
      console.log(response);
      var len = response.length;
      $("#tabledata").empty();
      for (var i = 0; i < len; i++) {
        var id = response[i].id;
        var name = response[i].name;
        var email = response[i].email;
        var number = response[i].number;

        var tr_str =
          "<tr>" +
          "<td>" +
          id +
          "</td>" +
          "<td>" +
          name +
          "</td>" +
          "<td>" +
          email +
          "</td>" +
          "<td>" +
          number +
          "</td>" +
          "<td>" +
          group +
          "</td>" +
          "<td>" +
          "<button class='btn btn-success edit-id' data-id='" +
          id +
          "'>Edit</button>" +
          " <button class='btn btn-success delete-id' data-id='" +
          id +
          "'>Delete</button>" +
          "</td>" +
          "</tr>";

        $("#tabledata").append(tr_str);
      }
    },
  });
}

/*pegination */
function fetchData(page) {
  console.log("page " + page);
  $.ajax({
    url: "./display.php",
    type: "GET",
    data: { page_no: page },
    dataType: "json",
    success: function (response) {
      console.log(response);
      var len = response.length;
      $("#tabledata").empty();
      for (var i = 0; i < len; i++) {
        var id = response[i].id;
        var name = response[i].name;
        var email = response[i].email;
        var number = response[i].number;

        var tr_str =
          "<tr>" +
          "<td>" +
          id +
          "</td>" +
          "<td>" +
          name +
          "</td>" +
          "<td>" +
          email +
          "</td>" +
          "<td>" +
          number +
          "</td>" +
          "<td>" +
          "<button class='btn btn-success edit-id' data-id='" +
          id +
          "'>Edit</button>" +
          " <button class='btn btn-success delete-id' data-id='" +
          id +
          "'>Delete</button>" +
          "</td>" +
          "</tr>";

        $("#tabledata").append(tr_str);
      }
    },
  });
}

$(document).ready(function () {
  function handlePageClick(page_id) {
    $("#pagination ul.pagination li.page-item").removeClass("active");
    $("#pagination a.page-link#" + page_id)
      .parent()
      .addClass("active");
    console.log("page_id " + page_id);
    fetchData(page_id);
  }

  function getTotalPages() {
    return 3;
  }
  function hasNextPage() {
    var currentPage = parseInt(
      $("#pagination ul.pagination li.page-item.active a").attr("id")
    );
    var totalPages = getTotalPages();
    return currentPage < totalPages;
  }

  function hasPreviousPage() {
    var currentPage = parseInt(
      $("#pagination ul.pagination li.page-item.active a").attr("id")
    );
    return currentPage > 1;
  }

  function isFirstPage() {
    var currentPage = parseInt(
      $("#pagination ul.pagination li.page-item.active a").attr("id")
    );
    return currentPage === 1;
  }

  function isLastPage() {
    var currentPage = parseInt(
      $("#pagination ul.pagination li.page-item.active a").attr("id")
    );
    var totalPages = getTotalPages();
    return currentPage === totalPages;
  }

  function updateButtonState() {
    $("#pagination a#first, #pagination a#previous")
      .parent()
      .toggleClass("disabled", !hasPreviousPage());
    $("#pagination a#last, #pagination a#next")
      .parent()
      .toggleClass("disabled", !hasNextPage());
  }

  // Initial page load
  fetchData(1);

  $(document).on(
    "click",
    "#pagination a.page-link, #pagination a#next, #pagination a#previous, #pagination a#first, #pagination a#last",
    function (e) {
      e.preventDefault();

      if ($(this).attr("id") === "next") {
        if (hasNextPage()) {
          var currentPage = $(
            "#pagination ul.pagination li.page-item.active a"
          ).attr("id");
          var nextPage = parseInt(currentPage) + 1;
          handlePageClick(nextPage);
        }
      } else if ($(this).attr("id") === "previous") {
        if (hasPreviousPage()) {
          var currentPage = $(
            "#pagination ul.pagination li.page-item.active a"
          ).attr("id");
          var previousPage = parseInt(currentPage) - 1;
          handlePageClick(previousPage);
        }
      } else if ($(this).attr("id") === "first") {
        if (!isFirstPage()) {
          handlePageClick(1);
        }
      } else if ($(this).attr("id") === "last") {
        if (!isLastPage()) {
          handlePageClick(getTotalPages());
        }
      } else {
        var page_id = $(this).attr("id");
        handlePageClick(page_id);
      }

      updateButtonState();
    }
  );

  // Initial state setup
  updateButtonState();
});

/*dropdown */
function fetchDataByRecordsPerPage(page, recordsPerPage) {
  console.log("page " + page + ", recordsPerPage " + recordsPerPage);
  $.ajax({
    url: "./display.php",
    type: "GET",
    data: { page_no: page, records_per_page: recordsPerPage },
    dataType: "json",
    success: function (response) {
      console.log(response);
      var len = response.length;
      $("#tabledata").empty();
      for (var i = 0; i < len; i++) {
        var id = response[i].id;
        var name = response[i].name;
        var email = response[i].email;
        var number = response[i].number;

        var tr_str =
          "<tr>" +
          "<td>" +
          id +
          "</td>" +
          "<td>" +
          name +
          "</td>" +
          "<td>" +
          email +
          "</td>" +
          "<td>" +
          number +
          "</td>" +
          "<td>" +
          "<button class='btn btn-success edit-id' data-id='" +
          id +
          "'>Edit</button>" +
          " <button class='btn btn-success delete-id' data-id='" +
          id +
          "'>Delete</button>" +
          "</td>" +
          "</tr>";

        $("#tabledata").append(tr_str);
      }
    },
  });
}

document.addEventListener("DOMContentLoaded", function () {
  var selectElement = document.getElementById("numberSelect");

  for (var i = 5; i <= 20; i += 5) {
    var option = document.createElement("option");
    option.value = i;
    option.text = i;
    selectElement.appendChild(option);
  }

  fetchDataByRecordsPerPage(1, selectElement.value);

  selectElement.addEventListener("change", function () {
    var selectedValue = this.value;
    fetchDataByRecordsPerPage(1, selectedValue);
  });
});

/* Search */
function fetchDataBySearch(page, searchValue = "") {
  console.log("page " + page + ", searchValue " + searchValue);
  $.ajax({
    url: "./display.php",
    type: "GET",
    data: { page_no: page, search_term: searchValue },
    dataType: "json",
    success: function (response) {
      console.log(response);
      var len = response.length;
      $("#tabledata").empty();
      for (var i = 0; i < len; i++) {
        var id = response[i].id;
        var name = response[i].name;
        var email = response[i].email;
        var number = response[i].number;
        var tr_str =
          "<tr>" +
          "<td>" +
          id +
          "</td>" +
          "<td>" +
          name +
          "</td>" +
          "<td>" +
          email +
          "</td>" +
          "<td>" +
          number +
          "</td>" +
          "<td>" +
          "<button class='btn btn-success edit-id' data-id='" +
          id +
          "'>Edit</button>" +
          " <button class='btn btn-success delete-id' data-id='" +
          id +
          "'>Delete</button>" +
          "</td>" +
          "</tr>";

        $("#tabledata").append(tr_str);
      }
    },
  });
}

$(document).ready(function () {
  function handlePageClick(page_id, searchValue = "") {
    $("#pagination ul.pagination li.page-item").removeClass("active");
    $("#pagination a.page-link#" + page_id)
      .parent()
      .addClass("active");
    console.log("page_id " + page_id + "searchValue");
    fetchDataBySearch(page_id, searchValue);
  }

  $(".nameSearch").on("input", function () {
    var searchValue = $(this).val();
    handlePageClick(1, searchValue);
  });
  // Initial load
  handlePageClick(1);
});

/*Add Group*/
$("#group-submit").on("click", function () {
  $.ajax({
    url: "./group.php",
    type: "POST",
    data: {
      name: $("#group-name").val(),
      op: "insert",
    },
    success: function (result) {
      var response = JSON.parse(result);
      console.log(response);

      if (response.success) {
        $("#groupexampleModal").modal("hide");
        var selectOptions =
          '<option selected id="select-option" value="">--Select Group--</option>';
        response.groups.forEach(function (group) {
          selectOptions +=
            '<option value="' + group.id + '">' + group.name + "</option>";
        });

        $("#select-group").html(selectOptions);
      }
    },
  });
});
