<?php
include 'conn.php';
session_start();
$user_id = $_SESSION['userid'];
/*pagination */
$page_number = isset($_GET["page_no"]) ? $_GET["page_no"] : 1;
$records_per_page = isset($_GET["records_per_page"]) ? $_GET["records_per_page"] : 5;
$offset = ($page_number - 1) * $records_per_page;
/*search dropdown */
$search_term = isset($_GET["search_term"]) ? $_GET["search_term"] : "";
$search_condition = $search_term != "" ? "AND name LIKE '$search_term%'" : "";

$select_query = "SELECT * FROM contact WHERE userid = '$user_id' $search_condition ORDER BY id DESC LIMIT $offset, $records_per_page";

$result_set = mysqli_query($conn, $select_query);

if (!$result_set) {
    $error_message = "Error: " . mysqli_error($conn);
    echo json_encode(['success' => false, 'message' => $error_message]);
    exit;
}
$return_arr = array();
if (mysqli_num_rows($result_set) > 0) {
    while ($row = mysqli_fetch_array($result_set)) {
        $group_id = $row['group_id'];
        
        $group_name_query = "SELECT name FROM `group` WHERE id = $group_id";
        
        $group_name_result = mysqli_query($conn, $group_name_query);
        
            $group_name_row = mysqli_fetch_assoc($group_name_result);
            $group_name = $group_name_row['name'];
        
        $return_arr[] = array(
            "group_name" => $group_name 
        );
    }
}


echo json_encode($return_arr);

?>