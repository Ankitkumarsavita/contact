<?php
include 'conn.php';
/*take empty string variable print into html page */

if (isset($_POST['op'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $folder = "./images/" . $_FILES["uploadfile"]["name"];
    $error_messages = array();
    
    // echo"<pre>";
    // print_r($folder);
    // exit();

    $name_pattern = "/^([a-zA-Z' ]+)$/";
    $email_pattern = '/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/';
    $pass_pattern = '/^\d{6,}$/';
    if (empty($name)) {
        $error_messages[] = ['field' => 'name', 'error' => 'Name is required'];
        
    }
    if (!preg_match($name_pattern, $name) && !empty($name)) {
        $error_messages[] = ['field' => 'name', 'error' => 'Invalid name'];
    }
    if (empty($email)) {
        $error_messages[] = ['field' => 'email', 'error' => 'Email is required'];
    } elseif (!preg_match($email_pattern, $email) && !empty($email)) {
        $error_messages[] = ['field' => 'email', 'error' => 'Invalid email'];
    }
    if (empty($password)) {
        $error_messages[] = ['field' => 'password', 'error' => 'password is required'];
    } elseif (!preg_match($pass_pattern, $password) && !empty($password)) {
        $error_messages[] = ['field' => 'password', 'error' => 'Invalid password'];
    }
    if (empty($confirm_password)) {
        $error_messages[] = ['field' => 'confirm_password', 'error' => 'Invalid confrim password'];
    } elseif ($password != $confirm_password) {
        $error_messages[] = ['field' => 'confirm_password', 'error' => 'Password and Confirm Password do not match'];
    } else {
        $check_email_query = "SELECT * FROM users WHERE email = '$email'";
        $check_email_result = mysqli_query($conn, $check_email_query);

        if (mysqli_num_rows($check_email_result) > 0) {
            $emailError = "Email already exists. Please choose a different email.";
        }
    }

    $original_filename = $_FILES["uploadfile"]["name"];
    $file_extension = pathinfo($original_filename, PATHINFO_EXTENSION);
    $filename = 'user_' . time() . "." . $file_extension;
    $tempname = $_FILES["uploadfile"]["tmp_name"];
    $folder = "./images/" . $filename;
    if (move_uploaded_file($tempname, $folder)) {

        // echo "File uploaded successfully!";
    }
    /*if this condition is not empty then it will insert data into database*/
    if (!empty($name) && !empty($email) && !empty($password) && !empty($filename) && empty($nameError) && empty($emailError) && empty($passError) && empty(   $confirm_passError)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $query = 'INSERT INTO users(name, email, password,image) VALUES ("' . $name . '", "' . $email . '", "' . $hashed_password . '","' . $filename . '")';
        // echo"<pre>";
        // print_r($query);
        // exit();
        $result = mysqli_query($conn, $query);
        if ($result) {
            // header("Location: ./index.php");
            echo json_encode(['success' => true, 'message' => 'record inserted']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error updating record']);

        }
    }
}

?>